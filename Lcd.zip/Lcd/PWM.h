#include <avr/io.h>

void PWM_Init();
void Set_DutyCycle(int duty,int pin);