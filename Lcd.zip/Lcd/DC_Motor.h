#ifndef __DC_MOTOR
#define __DC_MOTOR



void DC_Init();
void motor_start(int direction);

#endif
